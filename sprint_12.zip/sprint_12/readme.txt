------------------*** Sprint 12 *** ------------------------
-------------- Proyecto: Automatización -------------------

El proyecto consta de los siguientes archivos:
1. Readme.txt
2. trending_by_time.csv
3. Enlace de dashboard: https://public.tableau.com/views/Automation_17253966448530/Dashboard1?:language=es-ES&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link
4. Presentación pdf

-------------------------------------------------------------
En la presentación se desglosan las gráficas contestando a las preguntas solicitadas para el proyecto.